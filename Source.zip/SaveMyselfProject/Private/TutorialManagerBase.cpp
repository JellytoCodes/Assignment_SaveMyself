// Fill out your copyright notice in the Description page of Project Settings.


#include "TutorialManagerBase.h"
#include "GameFramework/PlayerController.h"
#include "Kismet/GameplayStatics.h"

void ATutorialManagerBase::BeginPlay()
{
	Super::BeginPlay();
	
	APlayerController* PC = UGameplayStatics::GetPlayerController(this, 0);
	if(PC)
	{
		PC->bShowMouseCursor = true;
	}
}

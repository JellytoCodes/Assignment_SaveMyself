// Fill out your copyright notice in the Description page of Project Settings.


#include "DefenseSaveGame.h"

UDefenseSaveGame::UDefenseSaveGame()
{
	LastClearedStage = NAME_None;
}
